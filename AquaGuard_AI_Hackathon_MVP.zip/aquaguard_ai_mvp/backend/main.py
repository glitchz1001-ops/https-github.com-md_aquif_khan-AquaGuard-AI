"""
AquaGuard AI backend starter.
Run: pip install -r requirements.txt && uvicorn main:app --reload
This API is a development scaffold. Add authentication, authorization,
validation, TLS, rate limiting and production database rules before deployment.
"""
import os, json, time
from datetime import datetime, timezone
from typing import Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="AquaGuard AI API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS","http://localhost:8000").split(","),
                   allow_credentials=True, allow_methods=["GET","POST"], allow_headers=["*"])

incidents = []
latest = {}

class Telemetry(BaseModel):
    device_id: str
    building_id: str
    flow_lpm: float = Field(ge=0)
    pressure_bar: float = Field(ge=0)
    leak_detected: bool = False
    timestamp: Optional[datetime] = None

class IncidentUpdate(BaseModel):
    status: str
    assigned_to: Optional[str] = None

def assess(data: Telemetry):
    reasons = []
    if data.leak_detected: reasons.append("water-contact sensor activated")
    if data.pressure_bar < float(os.getenv("PRESSURE_LOW_BAR","1.0")):
        reasons.append("pressure below configured threshold")
    if data.flow_lpm > float(os.getenv("FLOW_HIGH_LPM","5.0")):
        reasons.append("flow above configured threshold")
    if data.leak_detected and data.pressure_bar < 1.0:
        severity = "critical"
    elif len(reasons) >= 2:
        severity = "warning"
    elif reasons:
        severity = "review"
    else:
        severity = "normal"
    return severity, reasons

@app.get("/health")
def health():
    return {"status":"ok","service":"aquaguard-api","mode":"starter"}

@app.post("/telemetry")
def ingest(data: Telemetry):
    severity, reasons = assess(data)
    item = data.model_dump()
    item["timestamp"] = (data.timestamp or datetime.now(timezone.utc)).isoformat()
    item["severity"] = severity
    item["reasons"] = reasons
    latest[data.device_id] = item
    if severity in ("critical","warning","review"):
        incidents.insert(0, {"id":f"AG-{int(time.time())}","device_id":data.device_id,
                             "building_id":data.building_id,"severity":severity,
                             "reasons":reasons,"status":"open","created_at":item["timestamp"]})
    # TODO: publish validated telemetry to Firebase and MQTT event pipeline.
    return {"accepted":True,"assessment":item}

@app.get("/telemetry/latest")
def get_latest():
    return latest

@app.get("/incidents")
def get_incidents():
    return incidents

@app.patch("/incidents/{incident_id}")
def update_incident(incident_id: str, update: IncidentUpdate):
    for incident in incidents:
        if incident["id"] == incident_id:
            incident["status"] = update.status
            incident["assigned_to"] = update.assigned_to
            return incident
    raise HTTPException(404, "Incident not found")
