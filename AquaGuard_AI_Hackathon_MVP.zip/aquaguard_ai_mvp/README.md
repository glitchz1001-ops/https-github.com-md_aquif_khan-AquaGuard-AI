# AquaGuard AI — Hackathon MVP starter

## Included
- `frontend/index.html`: responsive dashboard prototype with campus-location schematic, incident simulation, maintenance workflow, CSV export and demo AquaBot.
- `backend/main.py`: FastAPI telemetry ingestion and rule-based assessment starter.
- `firmware/esp32_sensor_node.ino`: ESP32 sensor-node starter for flow, pressure and leak sensors.
- `backend/.env.example`: integration configuration placeholders.

## Run the frontend
Open `frontend/index.html` in a modern browser. It works as a local demonstration and does not require a server.

## Run the backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```
Then open `http://127.0.0.1:8000/docs` for the API documentation. The API currently stores data in memory; it is not production persistence.

## Important integration work before a real deployment
1. **Proxi map:** The UI links to the supplied Proxi map. It uses a conceptual schematic, not copied coordinates or verified pipe routes. Obtain permitted embed/export/API access and map each surveyed sensor to a verified campus location.
2. **Firebase:** Create a Firebase project, enable Authentication, and configure database security rules. Add a server-side Firebase Admin SDK integration; never put service-account secrets in frontend code.
3. **MQTT:** Configure a broker with TLS, per-device credentials, ACLs and a topic convention such as `aquaguard/{device_id}/telemetry`. Add a backend MQTT subscriber and validate device identity.
4. **Machine learning:** Collect labelled normal/leak telemetry across occupancy patterns, train and validate an anomaly model, monitor false positives, and deploy it behind the API. The current detector is rules-only.
5. **Notifications:** Add server-side email/SMS/WhatsApp providers, retry handling, delivery logs and opt-in/recipient governance.
6. **Roles:** Implement authenticated roles (admin, technician, management), server-side authorization and audit logs.
7. **Valve safety:** Keep real valve actuation disabled until independent leak confirmation, operator approval, fail-safe design, manual override, emergency stop, electrical isolation and field testing are complete. Never actuate a campus water valve from this demo.
8. **Reports:** Generate PDF reports server-side from validated records; current frontend exports CSV and a text demo report.
9. **Mobile:** The responsive frontend adapts to mobile browsers. Native iOS/Android packaging is not included.

## API example
```bash
curl -X POST http://127.0.0.1:8000/telemetry \
  -H "Content-Type: application/json" \
  -d '{"device_id":"ESP32-MRU-001","building_id":"hostel-a","flow_lpm":8.2,"pressure_bar":0.7,"leak_detected":true}'
```

## Accuracy and safety
All frontend readings and locations are illustrative. Sensor thresholds, flow-meter K-factor, pressure conversion, leak-sensor polarity, sensor placement and water-saving calculations must be calibrated and verified on site. This package is a hackathon MVP starter, not a certified building-management or life-safety system.
