/*
 AquaGuard AI ESP32 sensor-node starter (Arduino framework)
 Hardware assumptions:
 - Pulse flow meter on FLOW_PIN
 - Analog pressure transducer on PRESSURE_PIN (use a suitable signal conditioner)
 - Digital water-contact leak sensor on LEAK_PIN
 IMPORTANT: Calibrate the flow meter K-factor and pressure voltage conversion.
 Never wire a 5V sensor output directly to an ESP32 GPIO/ADC.
*/
#include <WiFi.h>
#include <PubSubClient.h>

const char* WIFI_SSID = "YOUR_WIFI";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* MQTT_HOST = "YOUR_MQTT_HOST";
const int MQTT_PORT = 8883;
const char* MQTT_USER = "YOUR_DEVICE_USER";
const char* MQTT_PASSWORD = "YOUR_DEVICE_PASSWORD";
const char* DEVICE_ID = "ESP32-MRU-001";
const char* BUILDING_ID = "MRU-BUILDING-TO-CONFIRM";

#define FLOW_PIN 27
#define PRESSURE_PIN 34
#define LEAK_PIN 26

WiFiClientSecure secureClient; // Configure CA certificate before production use.
PubSubClient mqtt(secureClient);
volatile unsigned long pulseCount = 0;
unsigned long lastSample = 0;
const float FLOW_K_FACTOR = 7.5; // Example only: calibrate for your exact meter.

void IRAM_ATTR flowPulse() { pulseCount++; }

void connectWiFi() {
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) delay(500);
}
void connectMQTT() {
  while (!mqtt.connected()) {
    mqtt.connect(DEVICE_ID, MQTT_USER, MQTT_PASSWORD);
    if (!mqtt.connected()) delay(1500);
  }
}
float readPressureBar() {
  int raw = analogRead(PRESSURE_PIN);
  float voltage = raw * (3.3f / 4095.0f);
  // Replace with the transfer function from your pressure-transducer datasheet.
  return voltage; // Placeholder, NOT calibrated bar.
}
void setup() {
  Serial.begin(115200);
  pinMode(FLOW_PIN, INPUT_PULLUP);
  pinMode(LEAK_PIN, INPUT);
  attachInterrupt(digitalPinToInterrupt(FLOW_PIN), flowPulse, FALLING);
  analogReadResolution(12);
  connectWiFi();
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
}
void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) connectMQTT();
  mqtt.loop();
  if (millis() - lastSample >= 5000) {
    noInterrupts();
    unsigned long pulses = pulseCount;
    pulseCount = 0;
    interrupts();
    float frequencyHz = pulses / 5.0f;
    float flowLpm = frequencyHz / FLOW_K_FACTOR; // Verify meter calibration.
    float pressureRaw = readPressureBar();
    bool leak = digitalRead(LEAK_PIN) == HIGH; // Confirm sensor polarity.
    char payload[256];
    snprintf(payload, sizeof(payload),
      "{\"device_id\":\"%s\",\"building_id\":\"%s\",\"flow_lpm\":%.2f,\"pressure_bar\":%.2f,\"leak_detected\":%s}",
      DEVICE_ID, BUILDING_ID, flowLpm, pressureRaw, leak ? "true" : "false");
    String topic = String("aquaguard/") + DEVICE_ID + "/telemetry";
    mqtt.publish(topic.c_str(), payload);
    Serial.println(payload);
    lastSample = millis();
  }
}
